//
// Created by Lingyin on 2024/4/6.
//

#pragma once

#include "math/Vec.h"
#include "math/Mat.h"
#include<vector>

using std::max;
using std::min;

using std::vector;
#define Pointer




#ifdef Pointer
template<class T >
struct Texture{
private:
//    T* operator[] (const int& i) const ;
public:
    int n{}, m{};

    T* textureMap = nullptr;
//    vector<T > textureMap;

    explicit Texture(const vector<vector<T > > &M);
    __hd__ Texture() { n = m = 0; };
    __hd__ Texture(const Texture& texture);
    __hd__ ~Texture();
    __hd__ void resize(int n, int m);

    __hd__ T printfSum() const{
        T s;
        for(int i = 0; i < n * m; i ++){
            s = s + textureMap[i];
        }
        return s;
    }

public:
    __hd__ T& operator ()(const int& ii, const int& jj) const;

    __hd__ const T& sampleInt(const int & u, const int & v) const;
    __hd__ T interpolation(const T & a, const T & b, const float & v) const;

public:
    __hd__ T sample2D(float u, float v) const;
    __hd__ T sample2D(const Vec2& uv) const;
//    __hd__ T sampleAverage(const Vec2& uv, const float& r) const; // [0, 1]

    __hd__ Texture<T >& operator = (const Texture<T> & tt);
};


#endif
#ifndef Pointer

template<class T >
struct Texture{
private:
//    T* operator[] (const int& i) const ;
public:
    int n{}, m{};

//    T* textureMap = nullptr;
    vector<T > textureMap;

    explicit Texture(const vector<vector<T > > &M);
    __hd__ Texture() { n = m = 0; };
    __hd__ Texture(const Texture& texture);
    __hd__ ~Texture();
    __hd__ void resize(int n, int m);

    __hd__ T printfSum() const{
        T s;
        for(int i = 0; i < n * m; i ++){
            s = s + textureMap[i];
        }
        return s;
    }

public:
    __hd__ T& operator ()(const int& ii, const int& jj) const;

    __hd__ const T& sampleInt(const int & u, const int & v) const;
    __hd__ T interpolation(const T & a, const T & b, const float & v) const;

public:
    __hd__ T sample2D(float u, float v) const;
    __hd__ T sample2D(const Vec2& uv) const;
//    __hd__ T sampleAverage(const Vec2& uv, const float& r) const; // [0, 1]

    __hd__ Texture<T >& operator = (const Texture<T> & tt);
};

#endif