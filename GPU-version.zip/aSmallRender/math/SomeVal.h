
#pragma once


#define __hd__ __host__ __device__
#include<cmath>
#include<cstring>
#include<initializer_list>
#include<iostream>
#include<cassert>
#include<iomanip>
#include<algorithm>
#include<iostream>
#include<cstdio>
#include<iostream>
#include<cuda_runtime.h>
#include<vector>
#include<unordered_map>
#include<string>
#include<iomanip>

__hd__ const float myEps = 1e-3;
__hd__ const float myPi = 3.1415926535f;
__hd__ const float invMyPi = 1.f / myPi;


using std::cout;
using std::endl;

using std::min;
using std::max;

#define CUDA_CHECK(call) \
    do { \
        cudaError_t err = call; \
        if (err != cudaSuccess) { \
            std::cerr << "CUDA error at " << __FILE__ << ":" << __LINE__ << ": " \
                      << cudaGetErrorString(err) << std::endl; \
            exit(err); \
        } \
    } while (0)


#define CUDA_ERROR \
    {\
        cudaError_t err = cudaGetLastError(); \
        if (err != cudaSuccess) { \
            std::cerr << __LINE__ << " CUDA kernel launch failed1: " << cudaGetErrorString(err) << std::endl;\
            exit(0);\
        }\
    }

#define GET_IDX \
    auto idx = blockIdx.x * blockDim.x + threadIdx.x;  \
    auto totThread = gridDim.x * blockDim.x; \ 
    auto tmp = siz % totThread; \
    auto bb = siz / totThread; \ 
    auto ccl = bb * idx + min(tmp, idx); \
    auto ccr = ccl + bb + (idx < tmp);

/*
#define __ getCudaFunction(p) \

*/